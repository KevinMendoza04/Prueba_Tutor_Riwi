piso1 = "1er piso."
piso2 = "2do piso."
piso3 = "3er piso."
piso4 = "4to piso."
piso5 = "5to piso."

variable_true = "no"
while variable_true == "no":
    try:
        print("\n¡Bienvenid@! \nVamos a bajar las escaleras 🪜....")
        print(f"\n👋 Estamos en el {piso5}")
        pregunta = input(f"Quieres ir al piso de abajo 🔽? (si/no): ").strip().lower()
        if pregunta == "si":
            print("🪜 Bajando...")
            print("🪜")
            print("🪜")
            print("🪜")
            print(f"👋 Estamos en el {piso4}.")
        
        pregunta2 = input(f"Quieres ir al piso de abajo 🔽? (si/no): ").strip().lower()
        if pregunta2 == "si":
            print("🪜 Bajando...")
            print("🪜")
            print("🪜")
            print("🪜")
            print(f"👋 Estamos en el {piso3}.")
        
        pregunta3 = input(f"Quieres ir al piso de abajo 🔽? (si/no): ").strip().lower()
        if pregunta3 == "si":
            print("🪜 Bajando...")
            print("🪜")
            print("🪜")
            print("🪜")
            print(f"👋 Estamos en el {piso2}.")
            
        pregunta4 = input(f"Quieres ir al piso de abajo 🔽? (si/no): ").strip().lower()
        if pregunta4 == "si":
                print("🪜 Bajando...")
                print("🪜")
                print("🪜")
                print("🪜")
                print(f"👋 Estamos en el {piso1}.")
        
        pregunta5 = input("Deseas salir? (si/no): ").strip().lower()
        if pregunta5 == "si":
            print("\n🧘‍♂️  A descansar.")
        variable_true = "si"        
    except ValueError:
        print("Opcion invalida, intenta de nuevo.")        
